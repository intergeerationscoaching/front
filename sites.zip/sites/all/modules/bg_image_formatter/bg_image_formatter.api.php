<?php

/**
 * @file
 * Hooks for the bg_image_formatter module.
 */

/**
 * Alter hook.
 *
 * @param array $css_settings
 *   The CSS settings in an array.
 * @param array $context
 *   The context : entity_type, entity, item.
 */
function hook_bg_image_formatter_css_settings_alter($css_settings, $context) {

}
